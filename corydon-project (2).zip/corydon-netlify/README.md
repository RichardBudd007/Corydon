# Corydon Self Build — Project Manager

## Deploy to Netlify
1. Go to https://app.netlify.com/drop
2. Drag the entire `corydon-netlify` folder onto the page
3. Done — you'll get a live URL instantly

## Default Passwords
- Richard: corydon2025
- Sarah: corydon2025
- Builder/Contractor: buildcorydon
- Consultant: buildcorydon

## Changing Passwords
Open `index.html` in a text editor and find the USERS section:
```
const USERS = {
  richard:    { pass:'corydon2025', ... },
  ...
}
```
Change the `pass` values, re-upload to Netlify.

## Files
- index.html — Login screen
- app.html — Project manager app
- netlify.toml — Netlify configuration
